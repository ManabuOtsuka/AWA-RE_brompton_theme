<?php get_header(); ?>

<main>
<?php
if ( have_posts() ) :
while ( have_posts() ) : the_post();
?>
        <article id="post-<?php the_ID(); ?>" <?php post_class('entry'); ?>>
        <section id="main-tourdetail">
                <div class="title-container">
                        <h3 class="title-underline">ツアーコース詳細</h3>
                </div>
            <div class="main-tourdetail__wrapper">
                <div class="main-tourdetail__top">
                    <div class="main-tourdetail__image">
                        <p class="main-tourdetail__title">
                        <?php the_field('tour_title'); ?>
                        </p>
                            <ul class="fade">

                                    <?php 
                                        $image = get_field('picture1');
                                        if( !empty($image) ): ?>
                                        <li><img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>"></li>
                                     <?php endif; ?>

                                    <?php 
                                        $image = get_field('picture2');
                                        if( !empty($image) ): ?>
                                        <li><img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>"><li>
                                     <?php endif; ?>

                                     <?php 
                                        $image = get_field('picture3');
                                        if( !empty($image) ): ?>
                                        <li><img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>"></li>
                                     <?php endif; ?>

                                    <?php 
                                        $image = get_field('picture4');
                                        if( !empty($image) ): ?>
                                        <li><img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>"></li>
                                     <?php endif; ?>

                                    <?php 
                                        $image = get_field('picture5');
                                        if( !empty($image) ): ?>
                                        <li><img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>"></li>
                                     <?php endif; ?>

                            </ul>
                    </div>
                 </div>

                    <div class="main-tourdetail__text">
                            <h4><i class="fas fa-quote-left"></i> ツアーの概要</h4>
                            <?php the_field('tour_description'); ?>
                    </div>
                    <div class="main-tourdetail__info">
                            <div class="main-tourdetal__time"><h4><i class="far fa-clock"></i> 所要時間：<?php the_field('course_time'); ?>時間</h4></div>								<div class="main-tourdetail__fee"><h4><i class="fas fa-yen-sign"></i> 料金：1人当り<?php the_field('price'); ?>円</h4></div>
                            <div class="main-tourdetail__location"><h4><i class="fas fa-map-marked-alt"></i> 開催場所：<?php the_field('place'); ?></h4>
                            </div>
                            <div class="main-tourdetail__gmap">
                                  <?php the_field('google_map_iframe'); ?>
                            </div>
                    </div>
            </div>
            </article>
        <?php
        endwhile;
        endif;
        ?>
            <a href="<?php echo home_url(); ?>/tour-products"><button class="main-products__detailbutton">コース一覧</button></a>
        </section>

    </main>
<?php get_footer(); ?>