<?php /*
   Template Name:Tour-Products-Index
*/ ?>

<?php get_header(); ?>

<main>
<section id="main-index__wrapper">
                <div class="title-container">
                        <h3 class="title-underline">ツアーコース一覧</h3>
                </div>
                <div class="main-index__lists">
                <?php
                if ( have_posts() ) : while ( have_posts() ) : the_post();
                ?>
                <?php get_template_part('loop', 'indexpage'); ?>
                <?php endwhile; endif; ?>
                </div>
        </section>

</main>

<?php get_footer(); ?>