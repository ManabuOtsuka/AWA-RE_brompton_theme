	
<?php
  $args = array(
      'category_name' => '', /* 投稿タイプを指定 */
      'post_type' => 'navigators'
  );
$my_query = new WP_Query( $args );
while ( $my_query->have_posts() ) : $my_query->the_post(); ?>
<div class="main-index__navilist">
    <div class="main-navilist__decoration">

    </div>
    <div class="main-navilist__textarea">
            <div class="main-navilist__name">
                <?php the_field('name', get_the_ID()); ?>
            </div>
            <div class="main-navilist__language">
            <?php $lang = get_field('language', get_the_ID());
            if( $lang ): ?>
            English
            <?php endif; ?>
            </div>
        <div class="main-navilist__pref">
        <i class="fas fa-map-marker-alt"></i> 対応エリア: <?php the_field('field', get_the_ID()); ?>
        </div>
        <div class="main-navilist__message">
        <i class="fas fa-quote-left"></i> 一言紹介<br><?php the_field('message', get_the_ID()); ?>
        </div>
    </div>
    <div class="main-navilist__photo">
    <?php $image = get_field('photo', get_the_ID());
            if( !empty($image) ): ?>
            <img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>">
    </div>
    <?php endif; ?>
    </div>
<?php endwhile; wp_reset_postdata(); ?>