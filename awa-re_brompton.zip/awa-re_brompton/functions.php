<?php
/**
 * AWA-RE_Brompton functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package AWA-RE_Brompton
 */

if ( ! function_exists( 'awa_re_brompton_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function awa_re_brompton_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on AWA-RE_Brompton, use a find and replace
		 * to change 'awa-re_brompton' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'awa-re_brompton', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'menu-1' => esc_html__( 'Primary', 'awa-re_brompton' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'awa_re_brompton_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
	}
endif;
add_action( 'after_setup_theme', 'awa_re_brompton_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function awa_re_brompton_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'awa_re_brompton_content_width', 640 );
}
add_action( 'after_setup_theme', 'awa_re_brompton_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function awa_re_brompton_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'awa-re_brompton' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'awa-re_brompton' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'awa_re_brompton_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function awa_re_brompton_scripts() {
	wp_enqueue_style( 'awa-re_brompton-style', get_stylesheet_uri() );

	wp_enqueue_script( 'awa-re_brompton-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );

	wp_enqueue_script( 'awa-re_brompton-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'awa_re_brompton_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

// カスタム投稿タイプの追加
add_action( 'init', 'create_post_type' );
function create_post_type() {
register_post_type( 'tourdetail', // 投稿タイプ名の定義
array(
 'labels' => array(
 'name' => __( 'ツアー商品' ), // 表示する投稿タイプ名
 'singular_name' => __( 'tourdetail' )
),
 'public' => true,
 'menu_position' => 5,
 'has_archive' => true,
 'show_in_rest' => true,
 'supports' => array('title','editor','thumbnail') 
)
);
register_post_type( 'navigators', // 投稿タイプ名の定義
array(
 'labels' => array(
 'name' => __( 'ナビゲーター' ), // 表示する投稿タイプ名
 'singular_name' => __( 'navigators' )
),
 'public' => true,
 'menu_position' => 5,
 'has_archive' => true,
 'show_in_rest' => true,
 'supports' => array('title','editor','thumbnail') 
)
);
}

// デフォルトサムネイルの設定
function default_thumbnail( $post_id ) {
    $post_thumbnail = get_post_meta( $post_id, $key = '_thumbnail_id', $single = true );
    $default_thumbnail_id = '2277';//　画像のポストIDを指定
    if ( !wp_is_post_revision( $post_id ) ) {
        if ( empty( $post_thumbnail ) ) {
            update_post_meta( $post_id, $meta_key = '_thumbnail_id', $meta_value = $default_thumbnail_id );
        }
    }
}
 
add_action( 'save_post', 'default_thumbnail' );

//問い合わせページのみreCAPTCHA表示
add_action( 'wp_enqueue_scripts', function() {
    if(is_page('contact')) return;
  wp_deregister_script( 'google-recaptcha' );
});