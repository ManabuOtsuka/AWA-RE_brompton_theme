<?php /*
   Template Name:Terms
*/ ?>

<?php get_header(); ?>

<main>
<section id="main-index__wrapper">
                <div class="title-container">
                        <h3 class="title-underline">Terms & Conditions</h3>
                </div>
                <div class="main-terms__wrapper">
                    <div class="main-terms__term1">
                        <h3>1. 標準旅行業約款</h3>
						<a href="https://awa-re.com/wp-content/uploads/2018/06/標準旅行業約款AWA-RE_2.pdf"><i class="fas fa-file-pdf"></i></a>
                    </div>
                    <div class="main-terms__term2">
                        <h3>2. 取引条件説明書(受注型企画旅行)</h3>
                        <a href="https://awa-re.com/wp-content/uploads/2018/06/受注型企画旅行_取引条件説明書面_20180623.pdf"><i class="fas fa-file-pdf"></i></a>
                    </div>
                    <div class="main-terms__term3">
                        <h3>3. 取引条件説明書(募集型企画旅行)</h3>
                        <a href="https://awa-re.com/wp-content/uploads/2018/06/募集型企画旅行_取引条件説明書面_20180623.pdf"><i class="fas fa-file-pdf"></i></a>
                    </div>
                    <div class="main-terms__cancel">
                        <h3>※旅行のキャンセルについて</h3>
                        <p>弊社主催の旅行についてキャンセルを行う場合は、予めご連絡ください。<br>
                        その際、下記に従いキャンセル料金+送金手数料を差し引いた額を返金いたします。<br>
                        ・キャンセル料金<br>
                        旅行開始日の前日から起算してさかのぼって<br>
                        8日目に当たる日以前→無料<br>
                        7~5日前まで→旅行代金の20%<br>
                        4~2日前まで→旅行代金の30%<br>
                        旅行開始日前日→旅行代金の50%<br>
                        当日キャンセルまたは不参加→ 旅行代金の100%</p>
                    </div>
                </div>
                
</section>

</main>

<?php get_footer(); ?>