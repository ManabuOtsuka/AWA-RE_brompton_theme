<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title>
       <?php
        if (!is_home() ){
            wp_title(' - ', true, 'right');
        }
        bloginfo('name');
        ?>
        </title>
    <!-- <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/reset.css"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/slick/slick.css">
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/slick/slick-theme.css">
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/style.css">
    <script src="https://kit.fontawesome.com/eea16c8a5a.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script>
	jQuery(function() {
        jQuery('.navToggle').click(function() {
            jQuery(this).toggleClass('active');
 
        if (jQuery(this).hasClass('active')) {
            jQuery('.global-nav').addClass('active');
        } else {
            jQuery('.global-nav').removeClass('active');
        }
    });
});
	</script>
    <?php 
    wp_enqueue_script('jquery');
    wp_head(); 
    ?>

</head>

<body>
        <div class="loading">
                <img src="<?php echo get_template_directory_uri(); ?>/images/Gear-2.6s-71px.gif" />
        </div>
    <div id="fb-root"></div>
	<div class="post_thumbnail">
    <?php the_post_thumbnail(); ?>
    </div>
	    <header class="main-header">
				
				<nav class="main-nav">
            <ul class="main-nav__items">
                <li class="main-nav__item">
                    <a href="<?php echo home_url(); ?>">HOME</a>
                </li>
                <li class="main-nav__item">
                    <a href="<?php echo home_url(); ?>/tour-products">TOURS</a>
                </li>
                <li class="main-nav__item">
                    <a href="<?php echo home_url(); ?>/staff">STAFF</a>
                </li>
                <li class="main-nav__item">
                <a href="<?php echo home_url(); ?>/contact">CONTACT</a>
                </li>
            </ul>
        </nav>
        </div>


    </header>
