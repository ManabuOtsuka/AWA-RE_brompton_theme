<?php
get_header();
?>

<main>
        <section id="main-hero">
            <img src="<?php echo get_template_directory_uri(); ?>/images/makeityours_2_animated.svg" width="50%" height="50%">
					<p>Bromptonと共に始まる、あなただけの物語。<br><br>Brompton旅切符ツアーin四国、始動。</p><h4>※現在Webサイト改修中につき、一部表示が乱れている場合がございます。※<br><br>※Internet Explorerでの表示には現在対応しておりません。※<br><br>※English Page Coming Soon!※</h4>
        </section>

        <section id="main-features">
            <div class="title-container">
            <h3 class="title-underline">Brompton旅切符ツアーの特色</h3>
            </div>
            <div class="main-feature__wrapper">
            <div class="main-feature__titleboxleftA">
			<p class="main-feature__title">坂は登らない！</p>
            <p>Bromptonはコンパクトな折り畳み自転車なので、JR、バス、タクシーとの組み合わせも自由自在。苦しい登り坂はバスやタクシーで上がって、下り坂だけのサイクリングを楽しむことだってできます！</p>
            </div>
            <div class="main-feature__imagerightA">
            <img src="<?php echo get_template_directory_uri(); ?>/images/brompton_rinkou.PNG" alt="">
            </div>
            <div class="main-feature__imageleftB">
            <img src="<?php echo get_template_directory_uri(); ?>/images/brompton_adliv.jpg" alt="">
            </div>
            <div class="main-feature__titleboxrightB">
			<p class="main-feature__title">フォトジェニック！</p>
            <p>四国の大自然と調和する、色とりどりのカラーフレーム。思い出の一枚に映える、ファッションアイテムとしても大活躍してくれます。</p>
            </div>
            <div class="main-feature__titleboxleftC">
			<p class="main-feature__title">新たな出会い！</p>
            <p>乗っているだけで、地元のみんなから声をかけられ、ふとした交流が始まる。Bromptonは人と人の距離を縮める、不思議な乗り物です。</p>
            </div>
            <div class="main-feature__imagerightC">
            <img src="https://awa-re.com/wp-content/uploads/2019/07/brompton_jingu.jpg" alt="">
            </div>
				<div class="main-feature__imageleftD">
					<img src="<?php echo get_template_directory_uri(); ?>/images/yuukatsu.JPG" alt="">
				</div>
				<div class="main-feature__titleboxrightD">
					<p class="main-feature__title">ゆったりポタリング！</p>
					<p>オシャレでかわいいBromptonと共に、四国の里山、瀬戸内の島々をのんびりお散歩。道中での寄り道を楽しむ事が、ポタリング最大の魅力です。
					</p>
				</div>
        </div>
        </section>

        <section id="main-story">
                <div class="title-container">
                        <h3 class="title-underline">Brompton &amp; Your Story</h3>
                </div>
                <div class="main-story__wrapper">
                    <div class="main-story__video">
                            <iframe src="https://www.youtube.com/embed/x9u6SUCk1iM" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
                            </iframe>
                    </div>
                    <div class="main-story__description">
                        <h3><i class="fas fa-play-circle main-story__playbutton"></i> Chapter 1：Bromptonを愛する男</h3>
						<p>Bromptonが大好きな地元のおっちゃん・ムネさん。Bromptonツアーが始まったきっかけについて、その思いを語ります。</p>
                    </div>

                    <div class="main-story__video">
                            <iframe src="https://www.youtube.com/embed/gNb2edw55n8" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
                            </iframe>
                    </div>
                    <div class="main-story__description">
                        <h3><i class="fas fa-play-circle main-story__playbutton"></i> Chapter 2：急傾斜地で暮らす人々</h3>
                        <p>徳島に来て1年が経った英語教師・Lucyは、この場所をもっと知りたいと、職場の友人を連れてBromptonのツアーに参加する事に。そこで出会ったのは、斜度40度を超える急傾斜地で、日本の原風景とも呼べる暮らしを続けている人達でした。</p>
                    </div>
                </div>
        </section>
        
        <section id="main-products">
            <div class="title-container">
            <h3 class="title-underline">ツアーコース一覧</h3>
            </div>
            <?php get_template_part('loop', 'slickslider'); ?>
            <?php get_template_part('loop', 'slickslidersub'); ?>
            <a href="<?php echo home_url(); ?>/tour-products"><button class="main-products__detailbutton">コース一覧</button></a>
        </section>
    </main>

<?php
get_footer();
