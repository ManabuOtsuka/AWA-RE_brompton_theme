<?php /*
   Template Name:Navigators-Index
*/ ?>

<?php get_header(); ?>
<main>
<section id="main-index__wrapper">
                <div class="title-container">
                            <h3 class="title-underline">旅切符ナビゲーター紹介</h3>
                </div>

                <div class="main-index__navilists">
                <?php
                if ( have_posts() ) : while ( have_posts() ) : the_post();
                ?>
                <?php get_template_part('loop', 'navigatorindex'); ?>
                <?php endwhile; endif; ?>
                </div>

                </section>
</main>

<?php get_footer(); ?>