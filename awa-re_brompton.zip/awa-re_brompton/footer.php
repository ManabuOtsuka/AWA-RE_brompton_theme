<?php
?>

	</div><!-- #content -->

    <footer class="main-footer">
        <nav class="main-footer__left">
            <ul>
                <li>株式会社AWA-RE</li>
				<li style="font-size: 0.85rem;">Brompton Pottering Association</li>
                <li>徳島県登録旅行業第3-165号</li>
            </ul>
            <ul>
                <li>
                <a href="<?php echo home_url(); ?>/about-us">About Us</a>
                </li>
                <li>
                <a href="<?php echo home_url(); ?>/privacy-policy">Privacy Policy</a>
                </li>
                <li>
                <a href="<?php echo home_url(); ?>/terms-conditions">Terms &amp; Conditions</a>
                </li>
            </ul>
            <ul>
                <li>
                <a href="https://www.facebook.com/AWA-RE-Inc-120552975451187/?ref=bookmarks"><i class="fab fa-facebook-square"></i> facebook</a>
                </li>
                <li>
                <a href="https://www.instagram.com/aware1955/"><i class="fab fa-instagram"></i> Instagram</a>
                </li>
            </ul>
        </nav>
        <nav class="main-footer__right">
            <ul>
                <li><i class="fas fa-map-marker-alt"></i> 徳島県美馬市脇町猪尻若宮南131-2</li>
                <li><i class="fas fa-phone-square-alt"></i> 0883-53-7055</li>
                <li><i class="far fa-envelope"></i> info(at)awa-re.com</li>
            </ul>
        </nav>
    </footer>
</div><!-- #page -->
<script>
            jQuery(window).load(function(){
            jQuery('.loading').fadeOut();	
            });

            jQuery(document).on('ready', function() {
                 jQuery('.slider-for').slick({
                 slidesToShow: 1,
                 slidesToScroll: 1,
                 arrows: false,
                 fade: true,
                 asNavFor: '.slider-nav'
                 }),
                 jQuery('.slider-nav').slick({
                 slidesToShow: 3,
                 slidesToScroll: 1,
                 asNavFor: '.slider-for',
                 dots: true,
                 centerMode: true,
                 focusOnSelect: true
                 })
             });
           </script>
           <script>
                jQuery(document).on('ready', function() {
                jQuery('.fade').slick({
                dots: true,
                infinite: true,
                speed: 500,
                fade: true,
                cssEase: 'linear'
            })
            });
</script>
          <script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/slick/slick.min.js"></script>
<?php wp_footer(); ?>

</body>
</html>
