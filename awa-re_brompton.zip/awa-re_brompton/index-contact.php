<?php /*
   Template Name:Contact
*/ ?>

<?php get_header(); ?>

<main>
<section id="main-index__wrapper">
                <div class="title-container">
                        <h3 class="title-underline__contact">お問合せ</h3>
                </div>
                <?php echo do_shortcode('[contact-form-7 id="98" title="contact-form-general"]'); ?>
</section>

</main>

<?php get_footer(); ?>