	
<?php
  $args = array(
      'category_name' => '', /* 投稿タイプを指定 */
      'post_type' => 'tourdetail'
  );
$my_query = new WP_Query( $args );
while ( $my_query->have_posts() ) : $my_query->the_post(); ?>
                    <div class="main-index__list">
                        <div class="main-index__listimage">
                        <div class="main-index__prefecture">
                                <p><?php the_field('prefecture', get_the_ID()); ?></p>
                        </div>
                        <?php $image = get_field('picture1', get_the_ID());
                        if( !empty($image) ): ?>
                            <a href="<?php the_permalink(); ?>"><img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>"></a>
                        </div>
                        <?php endif; ?>
                        <a href="<?php the_permalink(); ?>"><div class="main-index__listtitle"><?php the_field('tour_title', get_the_ID()); ?></div></a>
                    </div>
<?php endwhile; wp_reset_postdata(); ?>