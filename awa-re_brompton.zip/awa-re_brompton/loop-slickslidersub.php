<?php
  $args = array(
      'category_name' => '', /* 投稿タイプを指定 */
      'post_type' => 'tourdetail'
  );
$my_query = new WP_Query( $args );
?>
<ul class="slider-nav">
<?php while ( $my_query->have_posts() ) : $my_query->the_post(); ?>
                        <li>
                        <?php $image = get_field('picture1', get_the_ID());
                        if( !empty($image) ): ?>
                            <a href="#main-products"><img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>"></a>
                        </li>
                        <?php endif; ?>
<?php endwhile; wp_reset_postdata(); ?>
</ul>