<?php
  $args = array(
      'category_name' => '', /* 投稿タイプを指定 */
      'post_type' => 'tourdetail'
  );
$my_query = new WP_Query( $args );
?>
<ul class="slider-for">
<?php while ( $my_query->have_posts() ) : $my_query->the_post(); ?>
                        <li>
                            <?php
                                $image = get_field('picture1');
                            if( !empty($image) ): ?>
                                        <a href="#main-products"><img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" ></a>
                            <?php endif; ?>

                            <div class="main-products__titlebox">
                                
                                    <h2><?php the_field('tour_title', get_the_ID()); ?></h2>
                                    <p><?php the_field('tour_summary', get_the_ID()); ?></p>
                                    <a href="<?php the_permalink(); ?>"><button>詳細を見る</button></a>
                            </div>
                        </li>
<?php endwhile; wp_reset_postdata(); ?>
</ul>